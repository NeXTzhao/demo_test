file(REMOVE_RECURSE
  "CMakeFiles/bicycle_model.dir/main.cpp.o"
  "CMakeFiles/bicycle_model.dir/main.cpp.o.d"
  "bicycle_model"
  "bicycle_model.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/bicycle_model.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
