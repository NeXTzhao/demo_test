include("osqp-targets.cmake")
